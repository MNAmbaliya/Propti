// import axios from "axios";

// export const getStrataReport = async (address) => {
//     const api_url = process.env.REACT_APP_BACKEND_API_URL + "/test_api.php?action=getStrataReportByAddress&address="+address;
//     const data_post = {
//         "action": "getStrataReportByAddress",
//         "address": address,
//     }
    
//     const result = await axios.get( encodeURI(api_url) );
//     console.log(result);
//     return result
// }


import axios from "axios";

export const getStrataReport = async (address) => {
    // const data_post = {
    //     "action": "getReport",
    //     "address": address,
    // }
    // const result = await axios.post(
    //     process.env.REACT_APP_BACKEND_API_URL + "/test_api.php",
    //     data_post
    // )
    // return result

    

}