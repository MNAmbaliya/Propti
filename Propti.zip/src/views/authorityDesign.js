import React from 'react'

export default function AuthorityDesign() {
    return (
        <div>
            
        </div>
    )
}
